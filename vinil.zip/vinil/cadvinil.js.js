const cadastrar = document.getElementById("cadastrar");

function validar() {
    var nomedisco = document.getElementById("nomevinil").value;
    var erronomedisco = document.getElementById("erronomevinil");
    var erronomeartista = document.getElementById("erronomepresidente");
    var anolanc = document.getElementById("anolanc");
    var nomeartista = document.getElementById("nomepresidente").value;
    var precoompra = document.getElementById("precocompra")
    
    erronomedisco.textContent =""
    erronomeartista.textContent=""
    
    if (nomedisco == "") {
        erronomediso.textContent = "Nome do time deve ser digitado";
    }
    if (nomepresidente.launch <2) {
        erronomeartista.textContent = "Nome do presidente do clube deve ser digitado";

    }
    
    if (anolanc =="") {
        erroanolanc.textContent = "ano de fundação deve ser digitado

    
    {
    if (perseint(anolanc)<1900)
    erroanolanc.textContent = "digite o ano de fundação do time"
    }
    vaidardata(dataaquisição)
    if parseFloat(precoompra)<0 {
        erroprecocompra.textContent = "valor deve ser informado";
    }
    if (persfloat(precovenda)<10 || persfloat(preovenda>10000)) {
        erroprecovenda.textContent = "valor deve ser informado"
    }
    }

    }
    function validardata(vdata) {
        var dia = perseint(vdata[0]+vdata[1])
        var mes = perseint(vdata[3]+vdata[4])
        var ano = perseint(vdata[6]+vdata[7]+vdata[8]+vdata[9]);
        if (dia < 1 || dia > 31) }
        errodata.textContent ="dia invalido";
    }

    if(mes <1 ||mes >12) {
        errodata.textContent = "mes invalido":
    
    }
    if (dia==31 && (mes==2 || mes==4 || mes==6 || mes==9 || mes==11))
        errodata.textContent = "dia 31 invalido para o mes";
}

    if (dia==30 && mes==2) {
        errodata.textContent = "dia 30 invalido para fevereiro"

    }
    // ano bissexto 
    var fatori = ano % 4;
    var fatori = ano % 100;
    var fatori = ano % 400;
    var bissexto = 0;
    if (fatori == 0 && fatori2 !=0 || fatori == 0) {
        bissexto = 1;
    }
    if (dia==29 && mes == 2 && bisexto ==0){
        errodata.textContent = "29/fev invalido. Não é ano bissexto"
    }    
}

cadastrar.addEventListener("click", validar);